int encontra_caminho_exato(char ** T, int n, char * caminho);
